package com.example.ryan.forif_test;

import android.app.Activity;
import android.app.Notification;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;

import com.google.android.gms.common.api.GoogleApiClient;

  
         
         
         
          /**  * Created by RYAN on 2017. 5. 19..  */  

public class SplashActivity extends Activity { 
    private GoogleApiClient client;  

    public void onCreate(@Nullable Bundle savedInstanceState) { super.onCreate(savedInstanceState); 
        setContentView(R.layout.splash); Handler handler = new Handler() { 

            public void handleMessage(Message msg) { finish(); } 
        }; handler.sendEmptyMessageDelayed(0, 3000); 
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();  }  


    public void onStart() { 
        super.onStart(); 
        client.connect(); 
        Action viewAction = Action.newAction( 
                Action.TYPE_VIEW;
        "Splash Page", 
        Uri.parse("http://host/pah"), 
        Uri.parse("android-app://com.example.ryan.forif_test/http/host/path") 
        ); 
        AppIndex.AppIndexApi.start(client, viewAction);  
    }  

    public void onStop() { super.onStop(); 
        Action viewAction = Action.newAction( 
                Action.TYPE_VIEW, 
                "Spalsh Page", 
                Uri.parse("http://host/path"), 
                Uri.parse("android-app://com.example.ryan.forif_test/http/host/path") 
        ); 
        AppIndex.AppIndexApi.end(client, viewAction);
         client.disconnect(); } 
} 
